package org.aegisknight.audiere;

public class AudiereException extends java.lang.Exception {
  public AudiereException(String s) {
    super(s);
  }
}
